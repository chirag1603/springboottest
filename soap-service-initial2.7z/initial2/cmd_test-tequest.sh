#!/bin/bash

# cd /c/develop/code/JAVA/gs-soap-service/initial2

# TEST: ENPOINT http://localhost:8080/ws
curl --header "content-type: text/xml" -d @test/request.xml http://localhost:8080/ws > test/response.xml
# /c/develop/app/xmllint/libxml2-2.9.3-win32-x86_64/bin/xmllint.exe  --format test/response.xml

# NEW: ENPOINT https://ci-plumberv4.pre.shs.eu.dp.odp.cloud.vwgroup.com:44443/SUP/EnterpriseServices/TicketNotificationService/V1
